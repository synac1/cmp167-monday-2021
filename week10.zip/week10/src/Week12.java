import java.util.Arrays;

public class Week12 {
	public static void main(String[] args) {
		int []  mArr = {5 ,4 , 2 , 7 , 3 , 8, 100}; 
		
		System.out.println(Arrays.toString(mArr));
	
	}
}