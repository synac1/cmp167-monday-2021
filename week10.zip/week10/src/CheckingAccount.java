/*
 * 1- Inherit from BankAccount
 * 2- test out parent's method
 * 3- have at least a unique instance variable
 * 4- Override some parent's methods in child class
 * 
 */
public class CheckingAccount {

}
